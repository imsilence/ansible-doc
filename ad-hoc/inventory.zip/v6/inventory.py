#!/bin/env python3
#encoding: utf-8

inventory = {
    '_meta' : {
        'hostvars' : {
            'localhost' : {
                'ansible_connect' : 'local',
            },
            '51reboot' : {
                'ansible_host' : '112.74.164.107',
                'ansible_user' : 'silence',
            }
        }
    },
    'all' : {
        'hosts' : [
            'localhost'
        ]
    },
    'webserver' : {
        'hosts' : [
            '51reboot'
        ],
        'vars' : {
            'ansible_connect' : 'smart',
            'ansible_port' : 22,
            'ansible_become_user' : 'root',
            'ansible_python_interpreter' : '/bin/env python2.6'
        }
    }
}

if __name__ == '__main__':
    import json, sys
    print(json.dumps(inventory))
    sys.exit(0)